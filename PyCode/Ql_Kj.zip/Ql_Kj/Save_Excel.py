from __future__ import division
import uuid
import xlwt
import pandas as pd
# 保存擎天文官平台数据
def export_excel(export):
     #将字典列表转换为DataFrame

     export=[{"name": "10.31-星阅11点客服", "click": "64", "new_append": "5", "recharge_amount": "¥ 0"},
{"name": "10.30-星阅22点客服", "click": "34", "new_append": "1", "recharge_amount": "¥ 0"},
{"name": "10.30-灵锋19点客服", "click": "181", "new_append": "3", "recharge_amount": "¥ 0"},
{"name": "10.30-星阅19点客服", "click": "92", "new_append": "1", "recharge_amount": "¥ 0"},
{"name": "10.30-龙吟11点客服", "click": "65", "new_append": "5", "recharge_amount": "¥ 50.00"},
{"name": "10.30-灵锋11点客服", "click": "356", "new_append": "15", "recharge_amount": "¥ 0"},
{"name": "10.30-九霄11点客服", "click": "141", "new_append": "4", "recharge_amount": "¥ 0"},
{"name": "10.30-七点11点客服", "click": "404", "new_append": "9", "recharge_amount": "¥ 0"},
{"name": "10.30-清风11点客服", "click": "276", "new_append": "9", "recharge_amount": "¥ 0"},
{"name": "10.30-星阅11点客服", "click": "82", "new_append": "9", "recharge_amount": "¥ 30.00"},
{"name": "10.29-龙吟19点客服", "click": "54", "new_append": "1", "recharge_amount": "¥ 0"},
{"name": "10.29-灵锋19点客服", "click": "335", "new_append": "12", "recharge_amount": "¥ 0"},
{"name": "10.29-九霄19点客服", "click": "123", "new_append": "3", "recharge_amount": "¥ 0"},
{"name": "10.29-七点19点客服", "click": "474", "new_append": "17", "recharge_amount": "¥ 30.00"},
{"name": "10.29-清风19点客服", "click": "396", "new_append": "16", "recharge_amount": "¥ 180.00"},
{"name": "10.29-星阅19点客服", "click": "68", "new_append": "3", "recharge_amount": "¥ 0"},
{"name": "10.29-龙吟-11点客服", "click": "47", "new_append": "1", "recharge_amount": "¥ 0"},
{"name": "10.29-灵锋-11点客服", "click": "332", "new_append": "11", "recharge_amount": "¥ 0"},
{"name": "10.29-九霄-11点客服", "click": "109", "new_append": "3", "recharge_amount": "¥ 0"},
{"name": "10.29-七点-11点客服", "click": "218", "new_append": "4", "recharge_amount": "¥ 0"},
{"name": "10.29-清风-11点客服", "click": "196", "new_append": "8", "recharge_amount": "¥ 50.00"},
{"name": "10.29-星阅-11点客服", "click": "42", "new_append": "2", "recharge_amount": "¥ 0"},
{"name": "10.28-藏天22点客服", "click": "567", "new_append": "21", "recharge_amount": "¥ 0"},
{"name": "10.28-九霄22点客服", "click": "616", "new_append": "18", "recharge_amount": "¥ 100.00"},
{"name": "10.28-七点22点客服", "click": "812", "new_append": "35", "recharge_amount": "¥ 0"},
{"name": "10.28-清风22客服", "click": "661", "new_append": "33", "recharge_amount": "¥ 30.00"},
{"name": "10.28-藏天19点客服", "click": "339", "new_append": "10", "recharge_amount": "¥ 50.00"},
{"name": "10.28-九霄19点客服", "click": "291", "new_append": "9", "recharge_amount": "¥ 30.00"},
{"name": "10.28-七点19点客服", "click": "680", "new_append": "28", "recharge_amount": "¥ 90.00"},
{"name": "10.28-清风19点客服", "click": "464", "new_append": "15", "recharge_amount": "¥ 30.00"},
{"name": "10.28-藏天11点客服", "click": "281", "new_append": "6", "recharge_amount": "¥ 0"},
{"name": "10.28-九霄11点客服", "click": "286", "new_append": "7", "recharge_amount": "¥ 50.00"},
{"name": "10.28-七点11点客服", "click": "649", "new_append": "9", "recharge_amount": "¥ 0"},
{"name": "10.28-清风11点客服", "click": "570", "new_append": "19", "recharge_amount": "¥ 51.00"},
{"name": "10.28-龙吟-11时客服", "click": "120", "new_append": "5", "recharge_amount": "¥ 30.00"},
{"name": "10.28-轩辕-11时客服", "click": "40", "new_append": "0", "recharge_amount": "¥ 0"},
{"name": "10.28-龙吟-19时客服", "click": "92", "new_append": "4", "recharge_amount": "¥ 0"},
{"name": "10.28-轩辕-19时客服", "click": "30", "new_append": "0", "recharge_amount": "¥ 0"},
{"name": "10.27-龙吟-22时客服", "click": "78", "new_append": "5", "recharge_amount": "¥ 0"},
{"name": "10.27-轩辕-22时客服", "click": "22", "new_append": "1", "recharge_amount": "¥ 0"},
{"name": "10.27-龙吟-19时客服", "click": "93", "new_append": "4", "recharge_amount": "¥ 199.00"},
{"name": "10.27-轩辕19时客服", "click": "18", "new_append": "2", "recharge_amount": "¥ 0"},
{"name": "10.27-龙吟-11时客服", "click": "104", "new_append": "3", "recharge_amount": "¥ 0"},
{"name": "10.27-轩辕-11时客服", "click": "26", "new_append": "1", "recharge_amount": "¥ 0"},
{"name": "10.27-藏天19点客服", "click": "336", "new_append": "7", "recharge_amount": "¥ 0"},
{"name": "10.27-九霄19点客服", "click": "314", "new_append": "17", "recharge_amount": "¥ 50.00"},
{"name": "10.27-七点19点客服", "click": "627", "new_append": "20", "recharge_amount": "¥ 30.00"},
{"name": "10.27-清风19点客服", "click": "516", "new_append": "17", "recharge_amount": "¥ 100.00"},
{"name": "10.27-藏天11点客服", "click": "737", "new_append": "40", "recharge_amount": "¥ 380.00"},
{"name": "10.27-九霄11点客服", "click": "747", "new_append": "26", "recharge_amount": "¥ 560.00"},
{"name": "10.27-七点11点客服", "click": "962", "new_append": "43", "recharge_amount": "¥ 100.00"},
{"name": "10.27-清风11点客服", "click": "971", "new_append": "52", "recharge_amount": "¥ 280.00"},
{"name": "10.25-九霄-历史2", "click": "589", "new_append": "71", "recharge_amount": "¥ 657.00"},
{"name": "10.25-清风-历史5", "click": "479", "new_append": "51", "recharge_amount": "¥ 150.00"},
{"name": "10.25-清风-历史4", "click": "802", "new_append": "113", "recharge_amount": "¥ 310.00"},
{"name": "10.25-清风-历史3", "click": "531", "new_append": "38", "recharge_amount": "¥ 220.00"},
{"name": "10.25-清风-历史2", "click": "1318", "new_append": "166", "recharge_amount": "¥ 1,047.00"},
{"name": "10.25-清风-历史1", "click": "4251", "new_append": "570", "recharge_amount": "¥ 4,567.00"},
{"name": "10.25-九霄-历史4", "click": "855", "new_append": "114", "recharge_amount": "¥ 777.00"},
{"name": "10.25-九霄-历史3", "click": "317", "new_append": "24", "recharge_amount": "¥ 130.00"},
{"name": "10.25-藏天群发4", "click": "979", "new_append": "111", "recharge_amount": "¥ 477.00"},
{"name": "10.25-藏天群发3", "click": "460", "new_append": "34", "recharge_amount": "¥ 50.00"},
{"name": "10.25-九霄-历史1", "click": "1361", "new_append": "162", "recharge_amount": "¥ 2,114.00"},
{"name": "10.25-藏天群发2", "click": "476", "new_append": "34", "recharge_amount": "¥ 779.00"},
{"name": "10.25-藏天群发1", "click": "2753", "new_append": "320", "recharge_amount": "¥ 2,000.00"},
{"name": "10.25-七点-历史4", "click": "1820", "new_append": "157", "recharge_amount": "¥ 194.00"},
{"name": "10.25-七点-历史3", "click": "973", "new_append": "51", "recharge_amount": "¥ 80.00"},
{"name": "10.25-轩辕群发5", "click": "26", "new_append": "3", "recharge_amount": "¥ 0"},
{"name": "10.25-七点-历史2", "click": "1246", "new_append": "67", "recharge_amount": "¥ 377.00"},
{"name": "10.25-轩辕群发4", "click": "55", "new_append": "6", "recharge_amount": "¥ 0"},
{"name": "10.25-轩辕群发3", "click": "23", "new_append": "0", "recharge_amount": "¥ 0"},
{"name": "10.25-七点-历史1", "click": "4322", "new_append": "525", "recharge_amount": "¥ 1,837.00"},
{"name": "10.25-轩辕群发2", "click": "30", "new_append": "1", "recharge_amount": "¥ 0"},
{"name": "10.25-轩辕群发1", "click": "194", "new_append": "21", "recharge_amount": "¥ 100.00"},
{"name": "10.26-龙吟-22时客服", "click": "129", "new_append": "9", "recharge_amount": "¥ 50.00"},
{"name": "10.26-龙吟-19时客服", "click": "109", "new_append": "5", "recharge_amount": "¥ 0"},
{"name": "10.26-藏天-19点客服", "click": "645", "new_append": "27", "recharge_amount": "¥ 250.00"},
{"name": "10.26-灵锋-19点客服", "click": "1033", "new_append": "41", "recharge_amount": "¥ 50.00"},
{"name": "10.26-九霄-19点客服", "click": "720", "new_append": "33", "recharge_amount": "¥ 390.00"},
{"name": "10.26-七点-19点客服", "click": "1015", "new_append": "40", "recharge_amount": "¥ 201.00"},
{"name": "10.26-清风-19点客服", "click": "681", "new_append": "30", "recharge_amount": "¥ 110.00"},
{"name": "10.25-藏天11点客服", "click": "837", "new_append": "33", "recharge_amount": "¥ 34.00"},
{"name": "10.25-灵锋11点客服", "click": "1206", "new_append": "47", "recharge_amount": "¥ 250.00"},
{"name": "10.25-九霄11点客服", "click": "535", "new_append": "32", "recharge_amount": "¥ 180.00"},
{"name": "10.25-七点11点客服", "click": "1112", "new_append": "56", "recharge_amount": "¥ 100.00"},
{"name": "10.25-清风11点客服", "click": "386", "new_append": "28", "recharge_amount": "¥ 84.00"},
{"name": "10.24-龙吟-22时客服", "click": "63", "new_append": "6", "recharge_amount": "¥ 30.00"},
{"name": "10.25-龙吟-11时客服", "click": "76", "new_append": "3", "recharge_amount": "¥ 0"},
{"name": "10.24-龙吟-21时客服", "click": "43", "new_append": "2", "recharge_amount": "¥ 0"},
{"name": "10.24-藏天19点客服", "click": "406", "new_append": "23", "recharge_amount": "¥ 190.00"},
{"name": "10.24-灵锋19点客服", "click": "613", "new_append": "22", "recharge_amount": "¥ 0"},
{"name": "10.24-九霄19点客服", "click": "175", "new_append": "8", "recharge_amount": "¥ 100.00"},
{"name": "10.24-七点19点客服", "click": "434", "new_append": "15", "recharge_amount": "¥ 100.00"},
{"name": "10.24-清风19点客服", "click": "433", "new_append": "29", "recharge_amount": "¥ 47.00"},
{"name": "10.24-龙吟-11时客服", "click": "97", "new_append": "6", "recharge_amount": "¥ 0"},
{"name": "10.24-藏天11点客服", "click": "511", "new_append": "25", "recharge_amount": "¥ 50.00"},
{"name": "10.24-灵锋11点客服", "click": "826", "new_append": "34", "recharge_amount": "¥ 110.00"},
{"name": "10.24-九霄11点客服", "click": "329", "new_append": "27", "recharge_amount": "¥ 570.00"},
{"name": "10.24-七点11点客服", "click": "635", "new_append": "47", "recharge_amount": "¥ 180.00"},
{"name": "10.24-清风11点客服", "click": "731", "new_append": "55", "recharge_amount": "¥ 130.00"},
{"name": "10.24菜单2-5", "click": "105", "new_append": "1", "recharge_amount": "¥ 0"},
{"name": "10.24菜单2-4", "click": "163", "new_append": "0", "recharge_amount": "¥ 0"},
{"name": "10.24菜单2-3", "click": "114", "new_append": "2", "recharge_amount": "¥ 0"},
{"name": "10.24菜单2-2", "click": "119", "new_append": "0", "recharge_amount": "¥ 0"},
{"name": "10.24菜单2-1", "click": "334", "new_append": "1", "recharge_amount": "¥ 50.00"},
{"name": "10.24-龙吟-11时客服", "click": "0", "new_append": "0", "recharge_amount": "¥ 0"},
]

     # 将字典列表转换为DataFram
     pf = pd.DataFrame(list(export))
     #指定字段顺序
     order = ['name','click','new_append','recharge_amount']
     pf = pf[order]
     #将列名替换为中文
     columns_map = {
      'name':'入口',
      'click':'点击',
      'new_append':'新增关注',
      'recharge_amount':'充值金额',
     }
     pf.rename(columns = columns_map,inplace = True)
     #指定生成的Excel表格名称
     rd = uuid.uuid4()
     file_path = pd.ExcelWriter('擎天文馆%s.xls' % rd)
     #替换空单元格
     pf.fillna(' ',inplace = True)
     #输出
     pf.to_excel(file_path,encoding = 'utf-8',index = False)
     #保存表格
     file_path.save()
if __name__ == '__main__':
     #将分析完成的列表导出为excel表格
     export_excel('擎天文馆.xls')